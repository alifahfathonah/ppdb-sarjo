<footer class="container-fluid">
  <p class="text-muted text-center copyright">Copyright &copy; <?=$site['nama_sekolah'].' - '.$site['nama_website'];?> <?date('Y');?></p>
</footer>