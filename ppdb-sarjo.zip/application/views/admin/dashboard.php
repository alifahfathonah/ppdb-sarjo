<div class="container-fluid">

  <!-- Breadcrumbs-->
  <ol class="breadcrumb">
    <li class="breadcrumb-item active">
      <a href="<?=site_url('admin/dashboard');?>">Dashboard</a>
    </li>
  </ol>

  <!-- Page Content -->
  <h1>Dashboard</h1>
  <hr>
  <p>This is a great starting point for new custom pages.</p>

</div>